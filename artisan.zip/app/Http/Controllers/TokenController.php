<?php

namespace Ukrainediploms\Http\Controllers;

use Illuminate\Http\Request;

class TokenController extends Controller
{
    //
}
