@extends('thewall2.generalay')

@section ('title')
    Загрузка ADIF отчета
@stop

@section('content')
    <p>
                    name{{$ErrorUser}}
    </p>

@stop

