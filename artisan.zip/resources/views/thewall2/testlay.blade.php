<!DOCTYPE html>
<html lang="en">
<head>

</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50">



</body>
</html>