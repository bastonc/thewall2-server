<?php /* /home/u4247/domains/u4247.grey.elastictech.org/resources/views/thewall2/programmInfo.blade.php */ ?>


<?php $__env->startSection('title'); ?>

    Дипломная программа <?php echo e($programmName); ?> :: The Wall | Diplom


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="band" class="container text-center">
    <div id="band" class="container text-center">
                <h2><?php echo e($programmName); ?></h2>
    </div>


        <?php echo Form::open(array('url' => action('frontend@searchCall'), 'method' => 'post', 'role' => 'form', 'class' => 'form-horizontal')); ?>


        <div class="form-group">
            Введіть Ваш позивний:
            &nbsp;<?php echo Form::text('searchcall'); ?>

            <?php echo Form::hidden('Token', $token=$programmInfo[0]->token); ?>

            <button type="submit" class="btn btn-primary submit-button">Переглянути статистику</button>

            <?php echo Form::close(); ?>

        </div>
        <div class="row">


            <ul class="list-group ">

                <li class="list-group-item">
                    <?php $__currentLoopData = $programmInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row" >
                            <div class="col-md-4 center-block text-center " style="align-content: center">
                                <img src="<?php echo e($programm->image); ?>" width="100%">
                                <br />
                                <br />
                                <table border="1" style=" border-color: #fff; color:#101010; width:100%">
                                    <tr><td colspan="3" style="background-color:#a4aaae;">Потрібно набрати балів: <?php echo e($programm->scoreFinal); ?></td>
                                    <tr><td align="center" style="background-color:#a4aaae; width: 70%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;СПС&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                        <td align="center" style="background-color:#a4aaae;">Мода</td>
                                        <td align="center" style="background-color:#a4aaae" >&nbsp;&nbsp;&nbsp;Бали&nbsp;&nbsp;&nbsp;</td></tr>
                                    <?php $__currentLoopData = $spsMember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="background-color:#e8eeee"><td align="left" >&nbsp;<?php echo e($sps->call); ?>&nbsp;</td><td><?php echo e($sps->mode); ?></td><td align="right">&nbsp;<?php echo e($sps->score); ?>&nbsp;</td></tr>


                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>


                            </div>
                            <div class="col ">

                                <div class="row-md-8 text-justify" style="padding: 10px">
                                    <?php echo e($programm->description); ?>




                                </div>
                               <?php if($complitedCallArray!=NULL): ?>
                                <div class="row-md-8 text-center" style="padding: 10px">
                                    <p><strong>Дипломи видані:</strong></p>

                                        <?php $__currentLoopData = $complitedCallArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complitedCall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p><?php echo e($complitedCall->call); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                                </div>
                               <?php endif; ?>
                            </div>





                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
            </ul>

        <!--table border="0">
            <?php $__currentLoopData = $programmInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr><td colspan="3" bgcolor="#32cd32" height="1"></td></tr>
                <tr><td rowspan="2"><img src="<?php echo e($programm->image); ?>" width="500"></td>
                    <td width="450" align="center" bgcolor="#bababf"><strong><font color="#7f7f8f"><?php echo e($programm->name); ?></font></strong></td><td  bgcolor="#bababf">&nbsp;&nbsp; </td></tr>
                <tr><td width="450" align="center"  bgcolor="#bababf" colspan="2"><?php echo e($programm->description); ?></td></tr>



            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table-->


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('thewall2.programmlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>