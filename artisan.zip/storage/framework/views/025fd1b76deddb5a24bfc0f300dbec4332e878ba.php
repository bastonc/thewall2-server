<?php /* /home/u4247/domains/u4247.grey.elastictech.org/resources/views/thewall2/loginformsps.blade.php */ ?>
<?php $__env->startSection('title'); ?>

    Вход для СПС :: The Wall | Diplom


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="band" class="container text-center">
        <div id="band" class="container text-center">
            <h2>Вход для азагрузки отчета СПС</h2>
        </div>


        <?php echo e(Form::open(array('url' => action('ProgramsDiplom@loginsps'), 'method' => 'post', 'role' => 'form', 'class' => 'form-horizontal'))); ?>


        <div class="form-group">
            Введіть Ваш позивний СПС:
            <?php echo e(Form::text('spscall')); ?>

            <?php echo e(Form::password('spspass')); ?>


            <button type="submit" class="btn btn-primary submit-button">Увійти</button>

            <?php echo e(Form::close()); ?>

        </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('thewall2.programmlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>