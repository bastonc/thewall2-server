<?php /* /home/u4247/domains/u4247.grey.elastictech.org/resources/views/thewall2/indexProgramm.blade.php */ ?>


<?php $__env->startSection('title'); ?>
    Дипломные программы радиолюбителей :: The Wall | Diplom
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>







    <div id="band" class="container text-center">

        <h2>Активні дипломні програми</h2>
    </div>
    <!--div id="tour" class="bg-1 text-center"-->
        <div class="container text-center">
            <p align="right"><a href="/?sortby=FWD">Перші - старі програми</a> | <a href="/">Перші - нові програми</a>
            <ul class="list-group ">
                <?php $__currentLoopData = $Programms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">

                    <div class="row">
                        <div class="col-md-4 center-block ">
                            <a href="/programm/?p=<?php echo e($programm->token); ?>"><img src="<?php echo e($programm->image); ?>" width="100%"></a>
                        </div>

                        <div class="col ">
                            <p class="text-center"><a href="/programm/?p=<?php echo e($programm->token); ?>"><?php echo e($programm->name); ?></a></p>
                            <div class="body-layout">
                                <div class="wrap">
                                    <div id="short_text" class="text-description-content box-hide">
                            <div class="row-md-8">
                                <table width="90%"><tr><td align="left" style="font-size: 15px; color: #2F860F; ">Початок: <strong><?php echo e($programm->start_for_page); ?></strong></td><td align="right" style="font-size: 15px; color: #2F860F;">Необхідно набрати балів: <strong><?php echo e($programm->scoreFinal); ?></strong> </td></tr>
                                    <tr><td align="left" style="font-size: 15px; color: #9A1118	;">Завершення:<strong><?php echo e($programm->finish_for_page); ?></strong></td><td></td></tr></table>

                                <p align="left" style="font-size: 18px; color:#333333" ><b>СПС:</b>
                                    <?php $__currentLoopData = $programm->sps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $call): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <strong>&nbsp;<?php echo e($call->call); ?></strong>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </p>
                               <?php echo e($programm->description); ?>


                            </div>

                        </div>
                        <!--a href="#" id="short_text_show_link" class="novisited arrow-link text-description-more-link">
                            <span class="xhr arrow-link-inner">Читать полностью</span>&nbsp;→
                        </a-->
                    </div>
        </div>



                        </div>
                    </div>




                </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

        <?php echo e($Programms->links()); ?>

        </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('thewall2.generalay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>