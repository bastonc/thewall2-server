<?php /* /home/u4247/domains/u4247.grey.elastictech.org/resources/views/thewall2/logprogram.blade.php */ ?>


<?php $__env->startSection('title'); ?>
    Завантаженя ADIF звіта
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <div class="container">
            <center>
                <h1>Log</h1>
                <p>Програма <?php echo e($NameProgramm); ?></p>

                <?php if($resolvForm=="open"): ?>
                    <h3>Завантажити Adif звіт</h3>
                     <p> <?php echo e(Form::open(array('url' => action('uploadadifController@upload'), 'method' => 'post', 'role' => 'form', 'class' => 'form-horizontal', 'enctype'=>'multipart/form-data'))); ?>


                      <?php echo $__env->make('thewall2/form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="form-group">


                        <?php echo e(Form::submit('Загрузить файл')); ?>

                    </div>
                    <?php elseif($resolvForm=="close"): ?>
                    <p>Програма <br><?php echo e($NameProgramm); ?> <br> завершена</p>
                <?php endif; ?>
                </div>

                <?php echo e(Form::close()); ?></center></p>




        </div>
    </div>
    <?php if(isset($arrayRecord)): ?>
    <p><center>Завантажені QSO</center></p>
    <center>
        <table><tr bgcolor="#5f9ea0"><td>CALL</td><td>DATE</td><td>TIME</td><td>BAND</td><td>FREQ</td><td>TO STATION</td><td>RS(t)</td></tr>
            <?php $__currentLoopData = $arrayRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr><td> <?php echo e($res->call); ?></td><td><?php echo e($res->qso_date); ?></td><td><?php echo e($res->time_on); ?></td>
                    <td><?php echo e($res->band); ?></td><td><?php echo e($res->freq); ?></td><td> <?php echo e($res->operator); ?></td><td><?php echo e($res->rst_sent); ?></td></tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        <?php echo e($arrayRecord->appends(array('t' => $tokenprogramm))->links()); ?>

    </center>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('thewall2.generalay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>