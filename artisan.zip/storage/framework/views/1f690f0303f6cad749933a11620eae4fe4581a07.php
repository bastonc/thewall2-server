<?php /* /home/u4247/domains/u4247.grey.elastictech.org/resources/views/thewall2/reportqso.blade.php */ ?>
<?php $__env->startSection('title'); ?>
    Кабінет - звіт виданих дипломів :: The Wall
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="jumbotron">
        <div class="container">
            <center>
                <p style="font-size:15px;"><a onClick='history.back()'>Назад до QSO</a></p>
                <form>
                    <input type="button" value="Друкувати" onclick="window.print();">
                </form>

                <p>Звіт виданих дипломів для програми <?php echo e($programmArray[0]->name); ?></p>



                <table border="0" width="   90%">
                    <tr bgcolor="#eeeeee" align="center">
                        <td align="center"><b>DATE</b></td><td align="center"><b>CALL</b></td><td align="center"><b>OPERATOR</b></td><td align="center"><b>BAND</b></td>
                        <td align="center"><b>FREQ</b></td><td align="center"><b>MODE</b></td><td align="center"><b>RST</b></td><td align="center"><b>SCORE</b></td>
                    </tr>
                    <?php $index=0; ?>
                    <?php $__currentLoopData = $callArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $call): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr> <?php $index++;
                            if ($index%2 ==0) {$color="#dddddd";}else {$color="#ffffff";}
                            ?>
                            <td bgcolor="<?php echo e($color); ?>" align="center">&nbsp;<?php echo e($call->qso_date); ?>&nbsp;</td><td bgcolor="<?php echo e($color); ?>" align="center">&nbsp;<?php echo e($call->call); ?>&nbsp;</td>
                            <td bgcolor="<?php echo e($color); ?>" align="center">&nbsp;<?php echo e($call->operator); ?>&nbsp;</td><td bgcolor="<?php echo e($color); ?>" align="center">&nbsp;<?php echo e($call->band); ?>&nbsp;</td>
                            <td bgcolor="<?php echo e($color); ?>" align="center">&nbsp;<?php echo e($call->freq); ?>&nbsp;</td><td bgcolor="<?php echo e($color); ?>" align="center">&nbsp;<?php echo e($call->mode); ?>&nbsp;</td>
                            <td bgcolor="<?php echo e($color); ?>" align="center">&nbsp;<?php echo e($call->rst_sent); ?>&nbsp;</td><td bgcolor="<?php echo e($color); ?>" align="right">&nbsp;<?php echo e($call->score); ?>&nbsp;</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

            </center>

        </div>
    </div>


    </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('thewall2.generalay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>