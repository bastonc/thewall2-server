<?php /* /home/u4247/domains/u4247.grey.elastictech.org/resources/views/thewall2/mail/image.blade.php */ ?>
<h1>Нова заявка на отримання диплому</h1>
<p>Радіоаматор <?php echo e($call); ?> виконав диплом <?php echo e($nameProgramm); ?></p>

<p>Увага, згідно з налаштуваннями дипломної программи <strong>здобувач отримав диплом на сайті</strong></p>
