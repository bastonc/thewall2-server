<?php /* /home/u4247/domains/u4247.grey.elastictech.org/resources/views/thewall2/report.blade.php */ ?>
<?php $__env->startSection('title'); ?>
    Кабінет - звіт виданих дипломів :: The Wall
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="jumbotron">
        <div class="container">
            <center>
                <p style="font-size:15px;"><a href="/cabinet">Повернутися до кабінету</a></p>
                <form>
                    <input type="button" value="Друкувати" onclick="window.print();">
                </form>

                <p>Звіт виданих дипломів для програми <?php echo e($programmArray[0]->name); ?></p>


                <table border="0" width="50%">
                    <tr bgcolor="#eeeeee" align="center">
                        <td><b>CALL</b></td><td><b>SCORE</b></td>
                    </tr>
                    <?php $index=0; ?>
                    <?php $__currentLoopData = $callArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $call): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr> <?php $index++;
                            if ($index%2 ==0) {$color="#dddddd";}else {$color="#ffffff";}
                            ?>
                            <td bgcolor="<?php echo e($color); ?>"><a href="/admin/reportoper?t=<?php echo e($programmArray[0]->token); ?>&call=<?php echo e($call->call); ?>"><?php echo e($call->call); ?></a></td></td><td bgcolor="<?php echo e($color); ?>" align="right"><?php echo e($call->score); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

            </center>

        </div>
        </div>


    </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('thewall2.generalay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>