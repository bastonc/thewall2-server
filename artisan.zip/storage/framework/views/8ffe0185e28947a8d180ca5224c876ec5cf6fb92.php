<?php /* /home/u4247/domains/u4247.grey.elastictech.org/resources/views/thewall2/form.blade.php */ ?>
<div class="form-group">

        <?php echo e(Form::file('upfile')); ?>

        <?php echo e(Form::hidden('Token', $Token)); ?>


</div>
