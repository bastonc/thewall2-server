<?php /* /home/u4247/domains/u4247.grey.elastictech.org/resources/views/thewall2/resultcallcompleted.blade.php */ ?>


<?php $__env->startSection('title'); ?>
    Результати пошуку в програмі <?php echo e($programmName); ?> для <?php echo e($call); ?> :: The Wall | Diplom
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>





    <div id="band" class="container text-center">

        <div id="band" class="container text-center">
            <h2><?php echo e($programmName); ?></h2>
        </div>


            <?php echo Form::open(array('url' => action('frontend@searchCall'), 'method' => 'post', 'role' => 'form', 'class' => 'form-horizontal')); ?>


            <div class="form-group">
                Введіть Ваш позивний:
                &nbsp;<?php echo Form::text('searchcall',""); ?>

                <?php echo Form::hidden('Token', $tokenProgramm); ?>

                <button type="submit" class="btn btn-primary submit-button">Переглянути статистику</button>

                <?php echo Form::close(); ?>

            </div>

            <ul class="list-group ">

                    <li class="list-group-item">
                        <?php $__currentLoopData = $programmInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row" >
                            <div class="col-md-4 center-block " >
                                <img src="<?php echo e($programm->image); ?>" width="80%">
                            </div>
                            <div class="col ">
                                <p class="text-center"><a href="/programm/?p=<?php echo e($programm->token); ?>"><?php echo e($programm->name); ?></a></p>
                                <div class="body-layout">
                                    <div class="wrap">
                                        <div id="short_text" class="text-description-content box-hide">
                                <div class="row-md-8">
                                    <p align="left"><b>Потрібно набрати:</b> <?php echo e($programm->scoreFinal); ?>

                                    <?php $scoreFinal=$programm->scoreFinal;?>
                                        <br /><b>СПС:</b>
                                        <?php $__currentLoopData = $programm->sps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spscall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            &nbsp;&nbsp;&nbsp;<?php echo e($spscall->call); ?> - <?php echo e($spscall->score); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </p>

                                    <?php echo e($programm->description); ?>


                                </div>
                                        </div>
                                        <!--a href="#" id="short_text_show_link" class="novisited arrow-link text-description-more-link">
                                            <span class="xhr arrow-link-inner">Читать полностью</span>&nbsp;→
                                        </a-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
            </ul>

        <div class="container text-center" style="background-color:#215D07; color: #FAFAFA; width: 100%" >
        <h2>ВІТАЄМО!</h2>
    <?php if($methodArray[0]==0): ?>
        <p>Ви виконали умови диплому "<?php echo e($programmName); ?>"<br>Будь ласка введіть E-mail куди вам відправити диплом</p>
        <p><em>Ваша адреса E-mail буде доправлена до дипломного менеджера програми </em></p>
                      <?php echo Form::open(array('url' => action('frontend@sendemail'), 'method' => 'post', 'role' => 'form', 'class' => 'form-horizontal')); ?>


             <div class="form-group" style="color: #2d2d30  ">

                      <?php echo Form::text('email', "Ваш E-mail", array("class" =>"searchinput")); ?>

                      <?php echo Form::hidden('key', "0"); ?>

                      <?php echo Form::hidden('token', $tokenProgramm); ?>

                      <?php echo Form::hidden('call', $call); ?>

                      <button type="submit" class=" btn btn-primary submit-button">Я виконав!</button>

                      <?php echo Form::close(); ?>

            </div>
    <?php endif; ?>
    <?php if($methodArray[0]==1): ?>
                <p>Ви виконали умови диплому "<?php echo e($programmName); ?>"<br>Будь ласка введіть Ваше ім'я латиніцею</p>
                <?php echo Form::open(array('url' => action('frontend@sendemail'), 'method' => 'post', 'role' => 'form', 'class' => 'form-horizontal')); ?>


                <div class="form-group" style="color: #2d2d30  ">

                    <?php echo Form::text('name', "Ім'я",array("class" =>"pageinput")); ?>

                    <?php echo Form::hidden('key', "1"); ?>

                    <?php echo Form::hidden('token', $tokenProgramm); ?>

                    <?php echo Form::hidden('call', $call); ?>

                    <?php echo Form::hidden('x', $methodArray[1]); ?>

                    <?php echo Form::hidden('y', $methodArray[2]); ?>

                    <?php echo Form::hidden('color', $methodArray[3]); ?>

                    <button type="submit" class=" btn btn-primary submit-button">Я виконав!</button>

                    <?php echo Form::close(); ?>

                </div>
    <?php endif; ?>


        </div>


        <ul class="list-group ">
            <li class="list-group-item">
                <div class="row text-center text-uppercase" style="background: #500A16; color: #cacaca">
                    <p>Всього балів: <?php echo e($totalScore); ?></p>
                </div>
                <div class="row text-center text-uppercase" style="background: #500A16; color: #cacaca">
                    <p>З потрібних: <?php echo e($scoreFinal); ?></p>
                </div>
                <div class="row" style="background:  #500A16; color: #cacaca">
                    <div class="col-md-2 center-block ">
                        OPERATOR
                    </div>
                    <div class="col-md-2 center-block ">
                        CALL
                    </div>
                    <div class="col-md-1 center-block ">
                        RS(T)
                    </div>
                    <div class="col-md-2 center-block ">
                        BAND
                    </div>
                    <div class="col-md-2 center-block ">
                        DATE
                    </div>
                    <div class="col-md-1 center-block ">
                        MODE
                    </div>
                    <div class="col-md-2 center-block ">
                        SCORE
                    </div>
                </div>
            <?php $__currentLoopData = $searchCallInProgramm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qsoinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <div class="row">
                        <div class="col-md-2 center-block ">
                            <?php echo e($qsoinfo->call); ?>

                        </div>
                        <div class="col-md-2 center-block ">
                            <?php echo e($qsoinfo->operator); ?>

                        </div>
                        <div class="col-md-1 center-block ">
                            <?php echo e($qsoinfo->rst_sent); ?>

                        </div>
                        <div class="col-md-2 center-block ">
                            <?php echo e($qsoinfo->band); ?>

                        </div>
                        <div class="col-md-2 center-block ">
                            <?php echo e($qsoinfo->qso_date); ?>

                        </div>
                        <div class="col-md-1 center-block ">
                            <?php echo e($qsoinfo->mode); ?>

                        </div>
                        <div class="col-md-2 center-block ">
                            <?php echo e($qsoinfo->score); ?>

                        </div>
                    </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </li>
            <li class="list-group-item">
            <div class="row text-center text-uppercase" style="background: #500A16; color: #cacaca">
                <p>Всього балів: <?php echo e($totalScore); ?></p>
            </div>
            </li>

    </ul>
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('thewall2.programmlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>