<?php /* /home/u4247/domains/u4247.grey.elastictech.org/resources/views/thewall2/searchresult.blade.php */ ?>
<?php $__env->startSection('title'); ?>
    Результат за пошуком - <?php echo e($searchString); ?>  :: The Wall | Diplom
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>







    <div id="band" class="container text-center">

        <h2>Результат запиту: <?php echo e($searchString); ?></h2>
    </div>
    <!--div id="tour" class="bg-1 text-center"-->
    <div class="container text-center">
    <?php if($searchArray!=NULL): ?>
        <ul class="list-group ">
            <?php $__currentLoopData = $searchArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">

                    <div class="row">
                        <div class="col-md-4 center-block ">
                            <img src="<?php echo e($programm->image); ?>" width="100%">
                        </div>

                        <div class="col ">
                            <p class="text-center"><a href="/programm/?p=<?php echo e($programm->token); ?>"><?php echo e($programm->name); ?></a></p>
                            <div class="body-layout">
                                <div class="wrap">
                                    <div id="short_text" class="text-description-content box-hide">
                                        <div class="row-md-8">

                                            <?php echo e($programm->description); ?>


                                        </div>

                                    </div>
                                    <!--a href="#" id="short_text_show_link" class="novisited arrow-link text-description-more-link">
                                        <span class="xhr arrow-link-inner">Читать полностью</span>&nbsp;→
                                    </a-->
                                </div>
                            </div>



                        </div>
                    </div>




                </li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
        <?php else: ?>
            <p>Нічого не знайдено<br>Спробуйте ще</p>
    <?php endif; ?>


    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('thewall2.generalay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>