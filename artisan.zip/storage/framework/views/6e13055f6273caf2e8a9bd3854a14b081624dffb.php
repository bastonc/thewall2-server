<?php /* /home/u4247/domains/u4247.grey.elastictech.org/resources/views/thewall2/cabinet.blade.php */ ?>


<?php $__env->startSection('title'); ?>
    Кабинет - дипломные программы :: The Wall
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <div class="container">
            <center>
            <h2>Ваші дипломні програми</h2>
                <a href="/newprogramm">Створити нову програму</a>
            </center>





        </div>


    </div>
    <p align="right"><a href="/cabinet/?sortby=FWD">Перші - старі програми</a> | <a href="/cabinet/">Перші - нові програми</a></p>
    <center>
        <table border="0">
            <?php $__currentLoopData = $getList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($list->start_at==NULL): ?>
                   <?php $start="--" ?>
                <?php else: ?>
                    <?php $start=$list->start_at ?>
                <?php endif; ?>
                    <?php if($list->finish_at==NULL): ?>
                        <?php $finish=" -- " ?>
                    <?php else: ?>
                        <?php $finish=$list->finish_at ?>
                    <?php endif; ?>




                <?php if($list->status == "close"): ?>
                    <tr><td colspan="4" bgcolor="#aa9999" height="10"></td></tr>
                    <tr><td rowspan="6"><img src="<?php echo e($list->image); ?>" width="300"></td>
                        <td width="450" align="center" bgcolor="#CAC9AD"><strong><font color="#7f7f8f"><?php echo e($list->name); ?></font></strong></td><td  bgcolor="#CAC9AD">&nbsp;&nbsp; </td><td  bgcolor="#CAC9AD">&nbsp;&nbsp; </td></tr>
                    <tr><td width="450" align="center"  bgcolor="#CAC9AD" rowspan="5"><?php echo e($list->description); ?></td><td bgcolor="#CAC9AD" colspan="2" height="10"><font size="2" color="#233D39"><b>Створена:</b> <?php echo e($list->created_at); ?></font></td></tr>
                    <tr><td bgcolor="#CAC9AD" colspan="2" height="10"><font size="2" color="#34512E"><b>Стартувала:</b> <?php echo e($start); ?></font></td></tr>
                    <tr><td bgcolor="#CAC9AD" colspan="2" height="10"><font size="2" color="#5E3639"><b>Фінішувала:</b> <?php echo e($finish); ?></font> </td></tr>
                    <tr><td bgcolor="#CAC9AD" colspan="2">&nbsp; </td></tr>

                <tr><td width="150" align="center" bgcolor="#f5f5dc" height="10">Редагувати</td><td width="150" align="center" bgcolor="#f5f5dc" height="10"><a href="/log?t=<?php echo e($list->token); ?>">Log</a></td></tr>
                        <tr><td></td><td align="center"><a href="/admin/report?t=<?php echo e($list->token); ?>">Звіт виконаних</a></td><td width="150" align="center" bgcolor="#90ee90" height="10"><a href="/open?t=<?php echo e($list->token); ?>">Відновити</a></td><td width="150" align="center" bgcolor="#f08080" height="10"><a href="/admin/del?t=<?php echo e($list->token); ?>">Видалити</a></td></tr>
                    <tr><td colspan="4" bgcolor="#32cd32" height="1"> </td></tr>
                <?php elseif($list->status == "open"): ?>
                    <tr><td colspan="4" bgcolor="#aa9999" height="10"></td></tr>
                    <tr><td rowspan="6" valign="top" ><img src="<?php echo e($list->image); ?>" width="300"></td>
                        <td width="450" align="center"  bgcolor="#AEE770" height="10"><strong><?php echo e($list->name); ?></strong></td><td bgcolor="#AEE770"> &nbsp;&nbsp;</td><td bgcolor="#AEE770">&nbsp;&nbsp; </td></tr>
                    <tr><td width="750" align="center"  bgcolor="#AEE770" rowspan="5" valign="top"><?php echo e($list->description); ?></td><td bgcolor="#AEE770" colspan="2" height="10"><font size="2" color="#1B5A5A"><b>Створена:</b> <?php echo e($list->created_at); ?></font> </td></tr>
                    <tr><td bgcolor="#AEE770" colspan="2" height="10"><font size="2" color="#24913C"><b>Стартувала:</b> <?php echo e($start); ?></font> </td></tr>
                    <tr><td bgcolor="#AEE770" colspan="2" height="10"><font size="2" color="#96302E"><b>Фінішувала:</b> <?php echo e($finish); ?></font> </td></tr>
                    <tr><td bgcolor="#AEE770" colspan="2">&nbsp; </td></tr>
                    <tr><td width="150" align="center"  bgcolor="#f5f5dc" height="10" ><a href="/edit?t=<?php echo e($list->token); ?>" >Редагувати</a></td><td width="150" align="center"  bgcolor="#f5f5dc" height="10"><a href="/log?t=<?php echo e($list->token); ?>">Log/Додати ADIF</a></td></tr>
                        <tr><td></td><td align="center"><a href="/admin/report?t=<?php echo e($list->token); ?>">Звіт виконаних</a></td><td width="150" align="center" bgcolor="#f0e68c" height="10" ><a href="/close?t=<?php echo e($list->token); ?>">Завершити</a></td><td width="150" align="center" bgcolor="#f08080" height="10"><a href="/admin/del?t=<?php echo e($list->token); ?>">Видалити</a></td></tr>
                    <tr><td colspan="4" bgcolor="#32cd32" height="1"> </td></tr>
                <?php elseif($list->status == "new"): ?>
                    <tr><td colspan="4" bgcolor="#aa9999" height="10"></td></tr>
                    <tr><td rowspan="5"><img src="<?php echo e($list->image); ?>" width="300" heihgt="100"></td>
                        <td width="450" align="center" height="10"><?php echo e($list->name); ?></td><td colspan="2" height="10"> <font size="2" color="#1B5A5A"><b>Заснована:</b> <?php echo e($list->created_at); ?></font></td></tr>
                    <tr><td width="450" align="center" rowspan="4"><?php echo e($list->description); ?></td><td colspan="2" height="10"><font size="2" color="#24913C"><b>Стартувала: <?php echo e($start); ?></b></font> </td></tr>
                    <tr><td colspan="2" height="10">Фінішувала: <?php echo e($finish); ?> </td></tr>
                    <tr><td></td><td></td></tr>
                    <tr><td width="150" align="center"  bgcolor="#f5f5dc" height="10" ><a href="/edit?t=<?php echo e($list->token); ?>" >Редагувати</a></td><td width="150" align="center"  bgcolor="#f5f5dc" height="10">Log/Додати ADIF</td></tr>
                    <tr><td></td><td></td><td width="150" align="center" bgcolor=#66CCCC ><a href="/open?t=<?php echo e($list->token); ?>"  >Запустити</a></td><td width="150" align="center" bgcolor="#b22222"><a href="/admin/del?t=<?php echo e($list->token); ?>">Видалити</a></td></tr>
                    <tr><td colspan="4" bgcolor="#32cd32" height="1"></td></tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
        </table>
        <?php echo e($getList->links()); ?>

    </center>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('thewall2.generalay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>